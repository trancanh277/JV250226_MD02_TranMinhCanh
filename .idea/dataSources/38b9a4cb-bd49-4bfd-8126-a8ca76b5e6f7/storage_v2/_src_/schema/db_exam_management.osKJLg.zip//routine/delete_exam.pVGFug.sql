create
    definer = root@localhost procedure delete_exam(IN p_exam_id int)
begin
    delete from exams
    where exam_id = p_exam_id;
end;

