create
    definer = root@localhost procedure update_exam(IN p_exam_id int, IN p_exam_name varchar(150), IN p_exam_date date,
                                                   IN p_exam_time float, IN p_unit_time varchar(15),
                                                   IN p_exam_format varchar(100), IN p_status int)
begin
    update exams
    set exam_name = p_exam_name,
        exam_date = p_exam_date,
        exam_time = p_exam_time,
        unit_time = p_unit_time,
        exam_format = p_exam_format,
        status = p_status
    where exam_id = p_exam_id;
end;

