create
    definer = root@localhost procedure add_exam(IN p_exam_name varchar(150), IN p_exam_date date, IN p_exam_time float,
                                                IN p_unit_time varchar(15), IN p_exam_format varchar(100),
                                                IN p_status int)
begin
    insert into exams(exam_name, exam_date, exam_time, unit_time, exam_format, status)
    values (p_exam_name, p_exam_date, p_exam_time, p_unit_time, p_exam_format, p_status);
end;

