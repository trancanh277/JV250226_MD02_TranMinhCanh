create
    definer = root@localhost procedure find_exam_by_id(IN p_exam_id int)
begin
    select * from exams
    where exam_id = p_exam_id;
end;

