create
    definer = root@localhost procedure find_all_exams()
begin
    select * from exams;
end;

