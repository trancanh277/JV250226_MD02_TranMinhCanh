create
    definer = root@localhost procedure find_exams_by_name(IN p_exam_name varchar(150))
begin
    select * from exams
    where exam_name like concat('%', p_exam_name, '%');
end;

